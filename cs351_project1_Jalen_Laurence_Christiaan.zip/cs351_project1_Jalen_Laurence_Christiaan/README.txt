Readme file for zombie house

Try and avoid the zombies!

The entry point for the program is in main

Most resources for images are read through zombiePanel.  Images/sounds that are specific to a player or zombie are read in their respective classes.  

To open up a menu, you can press the I key at any point while the game has commenced.  

Basic controls
r key makes player run
wasd and the arrow buttons control the player movement.

Responsibilities
Jalen - made animation, sound, sound adjustment, game logic, movement updates, pathfinding, spawning firetraps/zombies/pillars in rooms. 

Laurence - made initial start screen, menu option to change default settings, procedural level generation. 

Christiaan - made fluid movement, floor/wall/scorcedmask tiles, lighting, graphic effects.